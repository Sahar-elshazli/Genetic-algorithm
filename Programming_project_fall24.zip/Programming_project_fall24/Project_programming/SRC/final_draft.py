import random
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Align import MultipleSeqAlignment
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio.Phylo import PhyloXML, write
from Bio import Phylo
import os
import matplotlib.pyplot as plt
from Bio import Phylo


def load_reference_genome(filepath):
    from Bio import SeqIO
    return SeqIO.read(filepath, "fasta")

def initialize_population(reference_genome, population_size, mutation_rate):
    population = []
    for i in range(population_size):
        mutated_genome = mutate_genome(reference_genome.seq, mutation_rate)
        population.append(SeqRecord(Seq(mutated_genome), id=f"genomei{i}", description=""))
    return population


def mutate_genome(sequence, mutation_rate):
    sequence = list(sequence)
    for base in range(len(sequence)):
        if random.random() < mutation_rate:
            sequence[base] = random.choice("ACGU".replace(sequence[base], ""))
    return ''.join(sequence)


def evaluate_fitness(sequence, reference_sequence, critical_sites, mutation_weights):
    fitness = 1.0
    for i, (base, ref_base) in enumerate(zip(sequence, reference_sequence)):
        if base != ref_base:
            if i in critical_sites:
                fitness -= critical_sites[i] * mutation_weights.get("critical", 0.1)
            else:
                fitness -= mutation_weights.get("non_critical", 0.05)
    return max(fitness, 0.1)

def select_population(population, fitness_scores, selection_size):
    total_fitness = sum(fitness_scores)
    if total_fitness == 0:
        print("Warning: All fitness scores are zero. Selecting randomly.")
        return random.sample(population, selection_size)
    selected_indices = random.choices(range(len(population)), weights=fitness_scores, k=selection_size)
    return [population[i] for i in selected_indices]

def generate_next_generation(population, mutation_rate, crossover_rate=0.1):
    next_gen = []
    for genome in population:
        new_genome_seq = mutate_genome(str(genome.seq), mutation_rate)
        if random.random() < crossover_rate:
            mate = random.choice(population)
            split_point = random.randint(0, len(new_genome_seq))
            new_genome_seq = new_genome_seq[:split_point] + str(mate.seq)[split_point:]

        next_gen.append(SeqRecord(Seq(new_genome_seq), id=f"{genome.id}_offspring", description=""))
    return next_gen
def calculate_population_fitness(population, reference_genome, critical_sites, mutation_weights):
    fitness_scores = []
    for genome in population:
        fitness = evaluate_fitness(
            sequence=str(genome.seq),
            reference_sequence=str(reference_genome.seq),
            critical_sites=critical_sites,
            mutation_weights=mutation_weights
        )
        fitness_scores.append(fitness)
    return fitness_scores

def construct_phylogenetic_tree(population):
    sequences = [
        SeqRecord(Seq(str(genome.seq)), id=f"{genome.id}_{i}", description="")
        for i, genome in enumerate(population)
    ]
    alignment = MultipleSeqAlignment(sequences)
    calculator = DistanceCalculator('identity')
    distance_matrix = calculator.get_distance(alignment)
    constructor = DistanceTreeConstructor(calculator)
    tree = constructor.upgma(distance_matrix)
    return tree

def output_population(population, filepath):
    directory = os.path.dirname(filepath)
    if not os.path.exists(directory):
        os.makedirs(directory)
    from Bio.SeqIO import write
    with open(filepath, "w") as f:
        write(population, f, "fasta")


def visualize_tree(tree, filepath):
    for clade in tree.find_clades():
        if clade.name:
            clade.name = clade.name.split("_")[0]
    fig = plt.figure(figsize=(15, 20))
    ax = fig.add_subplot(1, 1, 1)
    Phylo.draw(tree, do_show=False, axes=ax)
    plt.savefig(filepath, format="png", bbox_inches="tight")
    plt.show()

def simulate_evolution(reference_filepath, generations, population_size, mutation_rate, output_dir):
    reference_genome = load_reference_genome(reference_filepath)
    population = initialize_population(reference_genome, population_size, mutation_rate)
    critical_sites = {
        501: 5.0,  # N501Y in the RBD region
        484: 4.0,  # E484K associated with immune escape
        681: 3.0,  # Furin cleavage site
        417: 4.5,  # K417N/T linked to antibody resistance
        614: 3.5,  # D614G mutation
    }
    mutation_weights = {
        "critical": 0.2,
        "non_critical": 0.05,
    }
    for generation in range(generations):
        print(f"Generation {generation}")
        fitness_scores = calculate_population_fitness(
            population,
            reference_genome,
            critical_sites,
            mutation_weights
        )
        print(f"Average Fitness: {sum(fitness_scores) / len(fitness_scores)}")
        selected_population = select_population(population, fitness_scores, selection_size=population_size // 2)
        population = generate_next_generation(selected_population, mutation_rate)
        output_population(population, ".idea/inspectionProfiles/simulation_results")

    tree = construct_phylogenetic_tree(population)
    visualize_tree(tree, f"{output_dir}/final_tree.xml")


#only what you need so you can run the code , install the file from the folder containing the whole genome of SARS-COV-2 and then replace the path and that is it
simulate_evolution(
    reference_filepath="C:/Users/Lenovo/Downloads/sars_cov2_reference.fasta",  # You can find the file called sars_cov2_reference in the folder
    generations=30,
    population_size=100,
    mutation_rate=1.3e-6, # please do not change the mutation rate because that will affect the fitnees score and will affect the final phylogenetic tree
    output_dir="C:/Users/Lenovo/Downloads"
)